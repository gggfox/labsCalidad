 
+ Gerardo Galan Garzafox
+ A00821196

# Programa 1 PsP0

## Clases

### WhiteLines
+ tiene un contador y su getter
+ tiene un methodo que reviza la linea y aumenta el contador


### Comments
+ tiene un contador y su getter 
+ tine un booleano para comentarios multi linea
+ tiene un methodo void para revisar si solo hay una linea
+ tiene un methodo bool para ver si es multilinea, accesa el bool de multilinea

### Main
+ tiene una funcion para pedir el archivo
+ tiene una funcion para imprimir los resultados
	+ nombre de archivo, lineas en blanco, lineas de comentarios, lineas totals
	+ calcula lineas de codigo
+ tiene una variable para contar el total de lineas del archivo
+ hay 


## Tests
+ archivo normal (archivo1.txt)
+ archivo solo con espacion en blanco (archivo2.txt)
+ archivo con solo comentarios (test1.txt)
+ archivo que no existe